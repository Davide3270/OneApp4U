
window.metan = $("meta[name=az]");
window.metap = $("meta[name=path]");
window.server = metap.attr("content");

if(localStorage.NewAz==undefined || localStorage.NewAz==''){
	window.az = metan.attr("content");
}else{
	window.az = localStorage.NewAz; localStorage.NewAz='';
}
window.RAND = Math.random();
window.webSwitch = '';
sessionStorage.dataJson='X';
sessionStorage.APP='ON';
window.OS_userID = '';
window.OneSignal='OFF';
window.OnOffLine='online';

$('head').append('<link rel="stylesheet" href="https://www.jobapp.it/allScripts/css/framework7.minX4.css?'+RAND+'" type="text/css"/ >');
$('head').append('<script type="text/javascript" src="https://www.jobapp.it/allScripts/js/framework7.minX4.js?'+RAND+'"></script>');
$('head').append('<link rel="stylesheet" href="https://www.jobapp.it/allScripts/css/swiper.min.css?'+RAND+'" type="text/css"/ >');
$('head').append('<script type="text/javascript" src="https://www.jobapp.it/allScripts/js/swiper.min.js?'+RAND+'"></script>');
$('head').append('<link rel="stylesheet" href="https://www.jobapp.it/allScripts/css/all.css?'+RAND+'" type="text/css"/>');
$('head').append('<link rel="stylesheet" href="https://www.jobapp.it/allScripts/css/fonts.css?'+RAND+'" type="text/css"/>');


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

window.reStart=function(){location.href='nopanic.html';};

window.LoadScript = function(){
	
	window.mybody= 
	'<div id="app">'+
		'<div class="statusbar"></div>'+
		'<div class="panel panel-left panel-cover"></div>'+
		'<div class="panel panel-right panel-cover"></div>'+
		'<div class="view view-main safe-areas"></div>'+
	'</div>'
	$('body').prepend(mybody);
	$('body').height('');
	
	if(localStorage.oa4uGenapp=='NO' || localStorage.oa4uGenapp=='' || localStorage.oa4uGenapp==undefined || localStorage.oa4uGenapp=='undefined'){
		
		if(localStorage.AzdPrv=='' || localStorage.AzdPrv==undefined || localStorage.AzdPrv=='undefined'){
			$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic.js?'+RAND+'"></script>');
		}else if(localStorage.AzdPrv=='azd'){
			$('head').append('<link rel="stylesheet" href="'+dom+'/css/customAZD.css?'+RAND+'" type="text/css"/>');
			if(localStorage.adrAzdComplete!=''){
				$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_azd_compact.js?'+RAND+'"></script>');	
			}else{
				localStorage.adrAzdComplete='login';
				$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_azdpub_compact.js?'+RAND+'"></script>');
			}
		}else if(localStorage.AzdPrv=='prv'){
			$('head').append('<link rel="stylesheet" href="'+dom+'/css/customPRV.css?'+RAND+'" type="text/css"/>');
			if(localStorage.adrComplete!=''){
				$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_prv_compact.js?'+RAND+'"></script>');	
			}else{
				localStorage.adrComplete='login';
				$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_prv_compact.js?'+RAND+'"></script>');
			}
		}else if(localStorage.AzdPrv=='vstAzd'){
			$('head').append('<link rel="stylesheet" href="'+dom+'/css/customAZD.css?'+RAND+'" type="text/css"/>');
			$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_azdpub_compact.js?'+RAND+'"></script>');
			
		}else if(localStorage.AzdPrv=='vstPrv'){
			$('head').append('<link rel="stylesheet" href="'+dom+'/css/customPRV.css?'+RAND+'" type="text/css"/>');
			$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_prvpub_compact.js?'+RAND+'"></script>');
			
		}
		
	}else if(localStorage.oa4uGenapp=='OKOA4U'){
		
		if(localStorage.AzdPrv=='' || localStorage.AzdPrv==undefined || localStorage.AzdPrv=='undefined'){
			$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic.js?'+RAND+'"></script>');
		}else if(localStorage.AzdPrv=='azd'){
			if(localStorage.adrAzdComplete!=''){
				$('head').append('<link rel="stylesheet" href="'+dom+'/css/customAZD.css?'+RAND+'" type="text/css"/>');
				$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_azd.js?'+RAND+'"></script>');	
			}else{
				localStorage.adrAzdComplete='login';
				$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_azdpub.js?'+RAND+'"></script>');
			}
		}else if(localStorage.AzdPrv=='prv'){
			$('head').append('<link rel="stylesheet" href="'+dom+'/css/customPRV.css?'+RAND+'" type="text/css"/>');
			if(localStorage.adrComplete!=''){
				$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_prv.js?'+RAND+'"></script>');	
			}else{
				localStorage.adrComplete='login';
				$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_prv.js?'+RAND+'"></script>');
			}
		}else if(localStorage.AzdPrv=='vstAzd'){
			$('head').append('<link rel="stylesheet" href="'+dom+'/css/customAZD.css?'+RAND+'" type="text/css"/>');
			$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_azdpub.js?'+RAND+'"></script>');
			
		}else if(localStorage.AzdPrv=='vstPrv'){
			$('head').append('<link rel="stylesheet" href="'+dom+'/css/customPRV.css?'+RAND+'" type="text/css"/>');
			$('head').append('<script type="text/javascript" src="https://www.jobapp.it/business/NoPanic/js/nopanic_prvpub.js?'+RAND+'"></script>');
			
		}
	}
}


window.DeviceReady = function(){
	
	if (window.XMLHttpRequest) {NOTIFY = new XMLHttpRequest()} else {NOTIFY = new ActiveXObject("Microsoft.XMLHTTP")};
	NOTIFY.onreadystatechange = function() {
	if (NOTIFY.readyState == 4 && NOTIFY.status == 200) {
		
		NTFY=NOTIFY.responseText; 

		NTFY_VAL=NTFY.split('|');
		
		if(localStorage.ALERT_ON=='ON'){alert('Send NOTIFY: ' + NTFY_VAL[1]);}

		window.dom = NTFY_VAL[1].replace('http:','https:');  //ES:https://www.oneapp4u.com/job/OneApp4u Senza '/'
		domTmp = dom;
		lOf = domTmp.lastIndexOf('/');
		window.appPath = domTmp.slice(0,lOf+1); //ES:https://www.oneapp4u.com/job/ Con '/'
		temPath = appPath.replace('https://','');
		iOf = temPath.indexOf('/');
		window.workPath =  temPath.slice(iOf+1,-1);
		window.onlyWorkPath = workPath+'/'+az;
		window.mainPath = server+'/'; //ES:https://www.oneapp4u.com/ Con '/'
		
		if(localStorage.ALERT_ON=='ON'){alert('Send NOTIFY: ' + NTFY_VAL[2]);}			
													 
		if(NTFY_VAL[2]!='NoNotify' && sessionStorage.APP=='ON'){

			window.OS_userID = '';
			window.OneSignal='ON';

			var iosSettings = {};
			iosSettings["kOSSettingsKeyAutoPrompt"] = true;
			iosSettings["kOSSettingsKeyInAppLaunchURL"] = false;


			window.notificationOpenedCallback = function(jsonData) {
				sessionStorage.dataJson=JSON.stringify(jsonData);
			};

			window.plugins.OneSignal
			.startInit(""+NTFY_VAL[2])
			.handleNotificationReceived(notificationOpenedCallback)
			.handleNotificationOpened(notificationOpenedCallback)
			.inFocusDisplaying(window.plugins.OneSignal.OSInFocusDisplayOption.None)
			.iOSSettings(iosSettings)
			.endInit();
			
			setTimeout(function(){LoadScript();},2000);

		}else{
			setTimeout(function(){LoadScript();},2000);
		}

		response='';
		NTFY='';
		NTFY_VAL='';
	}};

	NOTIFY.open("post", server+"/php/ALLAPPDATA.php?"+RAND, true);
	NOTIFY.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var send = 'az='+az+'&allpath='+server+'/business';//***************** INSERIRE PATH CORRETTO ES: business
	if(localStorage.ALERT_ON=='ON'){alert('Send NOTIFY: ' + send);}
	NOTIFY.send(send);
}


var appInit = {
	// Application Constructor
	initialize: function() {
	this.bindEvents();
	},
	// Bind Event Listeners
	//
	// Bind any events that are required on startup. Common events are:
	// 'load', 'deviceready', 'offline', and 'online'.
	bindEvents: function() {
		document.addEventListener('deviceready', this.onDeviceReady, false);
		document.addEventListener('online', this.onOnline, false);
		document.addEventListener('offline', this.onOffline, false);
		document.addEventListener("backbutton", this.onBackKeyDown, false);
		document.addEventListener("resume", this.onResume, false);
		document.addEventListener("pause", this.onPause, false);
		document.addEventListener("resign", this.onResign, false);
	},
	// deviceready Event Handler
	//
	// The scope of 'this' is the event. In order to call the 'receivedEvent'
	// function, we must explicity call 'appInit.receivedEvent(...);'
	onDeviceReady: function() {
		appInit.receivedEvent('deviceready');
	},
	onOnline: function() {
		appInit.receivedEvent('online');
	},
	onOffline: function() {
		appInit.receivedEvent('offline');
	},
	onBackKeyDown: function() {
		appInit.receivedEvent('backbutton');
	},
	onResume: function() {
		appInit.receivedEvent('resume');
	},
	onPause: function() {
		appInit.receivedEvent('pause');
	},
	onPause: function() {
		appInit.receivedEvent('resign');
	},
    
	// Update DOM on a Received Event
	receivedEvent: function(id) {if(localStorage.ALERT_ON=='ON'){alert('Received Event: ' + id);}
		
		if(id=='deviceready'){
			clearTimeout(webSwitch); DeviceReady();
		}else if(id=='online'){
			if(OnOffLine=='offline'){OnOffLine='online'; reStart();}
		}else if(id=='offline'){
			OnOffLine='offline';
			$('body').html('<p style="text-align: center;font-size: xx-large;margin-top: 20%;background: rgb(146, 0, 0);color: white;font-family: monospace;">Offline</p><p style="text-align: center;font-size: x-large;background: rgb(146, 0, 0);color: white;font-family: monospace;">Your Connection<br>to the Internet is offline.<br>Please enable GSM or Wi-Fi.<br>Thanks OneApp4U.</p><div style="width: 100%;height: 100px;background-image: url(offline.png);background-repeat: no-repeat;background-position: center;background-size: contain;position: absolute;bottom: 30%;"></div>')
		}else if(id=='backbutton'){
			funEvent(id);
		}else if(id=='resume'){
			funEvent(id);
		}else if(id=='pause'){
			funEvent(id);
		}else if(id=='resign'){
			funEvent(id);
		}
	}
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* window.reStart=function(){
	setTimeout(function(){if(END=='NO'){location.href='index.html'}},60000);
}
reStart(); */

window.userAgent = navigator.userAgent || navigator.vendor || window.opera; 
if( userAgent.match( /iPad/i ) || userAgent.match( /iPhone/i ) || userAgent.match( /iPod/i )) {
	appInit.initialize(); 
	webSwitch=setTimeout(function(){sessionStorage.APP='OFF';appInit.onDeviceReady();},3000) 
}else if( userAgent.match( /Android/i )){
	appInit.initialize(); 
	webSwitch=setTimeout(function(){sessionStorage.APP='OFF';appInit.onDeviceReady();},3000)
}else{
	sessionStorage.APP='OFF';
	appInit.onDeviceReady();
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


