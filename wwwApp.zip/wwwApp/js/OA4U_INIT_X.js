
window.metan = $("meta[name=az]");
window.metap = $("meta[name=path]");
window.server = metap.attr("content");

if(localStorage.NewAz==undefined || localStorage.NewAz==''){
	window.az = metan.attr("content");
}else{
	window.az = localStorage.NewAz; localStorage.NewAz='';
}
window.RAND = Math.random();
window.RANDX='';
window.webSwitch = '';
sessionStorage.dataJson='X';
sessionStorage.APP='ON';
window.OS_userID = '';
window.OneSignal='OFF';
window.OnOffLine='online';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

window.reStart=function(){location.href='index.html';};

window.LoadScript = function(){
	
	if(localStorage.UPDATENOW=='ON'){window.RANDX='?'+RAND;}
	$('head').append('<script type="text/javascript" src="https://www.jobapp.it/allScripts/OA4U_BRIDGE_X.js'+RANDX+'"></script>');
}


window.DeviceReady = function(){
	
	if (window.XMLHttpRequest) {NOTIFY = new XMLHttpRequest()} else {NOTIFY = new ActiveXObject("Microsoft.XMLHTTP")};
	NOTIFY.onreadystatechange = function() {
	if (NOTIFY.readyState == 4 && NOTIFY.status == 200) {
		
		NTFY=NOTIFY.responseText; 

		NTFY_VAL=NTFY.split('|');
		
		if(localStorage.ALERT_ON=='ON'){alert('Send NOTIFY: ' + NTFY_VAL[1]);}

		window.dom = NTFY_VAL[1].replace('http:','https:');  //ES:https://www.oneapp4u.com/job/OneApp4u Senza '/'
		domTmp = dom;
		lOf = domTmp.lastIndexOf('/');
		window.appPath = domTmp.slice(0,lOf+1); //ES:https://www.oneapp4u.com/job/ Con '/'
		temPath = appPath.replace('https://','');
		iOf = temPath.indexOf('/');
		window.workPath =  temPath.slice(iOf+1,-1);
		window.onlyWorkPath = workPath+'/'+az;
		window.mainPath = server+'/'; //ES:https://www.oneapp4u.com/ Con '/'
		
		if(localStorage.ALERT_ON=='ON'){alert('Send NOTIFY: ' + NTFY_VAL[2]);}			
													 
		if(NTFY_VAL[2]!='NoNotify' && sessionStorage.APP=='ON'){

			window.OS_userID = '';
			window.OneSignal='ON';

			var iosSettings = {};
			iosSettings["kOSSettingsKeyAutoPrompt"] = true;
			iosSettings["kOSSettingsKeyInAppLaunchURL"] = false;


			window.notificationOpenedCallback = function(jsonData) {
				sessionStorage.dataJson=JSON.stringify(jsonData);
			};

			window.plugins.OneSignal
			.startInit(""+NTFY_VAL[2])
			.handleNotificationReceived(notificationOpenedCallback)
			.handleNotificationOpened(notificationOpenedCallback)
			.inFocusDisplaying(window.plugins.OneSignal.OSInFocusDisplayOption.None)
			.iOSSettings(iosSettings)
			.endInit();
			
			LoadScript();

		}else{
			LoadScript();
		}

		response='';
		NTFY='';
		NTFY_VAL='';
	}};

	NOTIFY.open("post", server+"/php/ALLAPPDATA.php?"+RAND, true);
	NOTIFY.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	var send = 'az='+az+'&allpath='+server+'/business';//***************** INSERIRE PATH CORRETTO ES: business
	if(localStorage.ALERT_ON=='ON'){alert('Send NOTIFY: ' + send);}
	NOTIFY.send(send);
}


var appInit = {
	// Application Constructor
	initialize: function() {
	this.bindEvents();
	},
	// Bind Event Listeners
	//
	// Bind any events that are required on startup. Common events are:
	// 'load', 'deviceready', 'offline', and 'online'.
	bindEvents: function() {
		document.addEventListener('deviceready', this.onDeviceReady, false);
		document.addEventListener('online', this.onOnline, false);
		document.addEventListener('offline', this.onOffline, false);
		document.addEventListener("backbutton", this.onBackKeyDown, false);
		document.addEventListener("resume", this.onResume, false);
		document.addEventListener("pause", this.onPause, false);
		document.addEventListener("resign", this.onResign, false);
	},
	// deviceready Event Handler
	//
	// The scope of 'this' is the event. In order to call the 'receivedEvent'
	// function, we must explicity call 'appInit.receivedEvent(...);'
	onDeviceReady: function() {
		appInit.receivedEvent('deviceready');
	},
	onOnline: function() {
		appInit.receivedEvent('online');
	},
	onOffline: function() {
		appInit.receivedEvent('offline');
	},
	onBackKeyDown: function() {
		appInit.receivedEvent('backbutton');
	},
	onResume: function() {
		appInit.receivedEvent('resume');
	},
	onPause: function() {
		appInit.receivedEvent('pause');
	},
	onPause: function() {
		appInit.receivedEvent('resign');
	},
    
	// Update DOM on a Received Event
	receivedEvent: function(id) {if(localStorage.ALERT_ON=='ON'){alert('Received Event: ' + id);}
		
		if(id=='deviceready'){
			clearTimeout(webSwitch); DeviceReady();
		}else if(id=='online'){
			if(OnOffLine=='offline'){OnOffLine='online'; reStart();}
		}else if(id=='offline'){
			OnOffLine='offline';
			$('body').html('<p style="text-align: center;font-size: xx-large;margin-top: 20%;background: rgb(146, 0, 0);color: white;font-family: monospace;">Offline</p><p style="text-align: center;font-size: x-large;background: rgb(146, 0, 0);color: white;font-family: monospace;">Your Connection<br>to the Internet is offline.<br>Please enable GSM or Wi-Fi.<br>Thanks OneApp4U.</p><div style="width: 100%;height: 100px;background-image: url(offline.png);background-repeat: no-repeat;background-position: center;background-size: contain;position: absolute;bottom: 30%;"></div>')
		}else if(id=='backbutton'){
			funEvent(id);
		}else if(id=='resume'){
			funEvent(id);
		}else if(id=='pause'){
			funEvent(id);
		}else if(id=='resign'){
			funEvent(id);
		}
	}
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* window.reStart=function(){
	setTimeout(function(){if(END=='NO'){location.href='index.html'}},60000);
}
reStart(); */

window.userAgent = navigator.userAgent || navigator.vendor || window.opera; 
if( userAgent.match( /iPad/i ) || userAgent.match( /iPhone/i ) || userAgent.match( /iPod/i )) {
	appInit.initialize(); 
	webSwitch=setTimeout(function(){sessionStorage.APP='OFF';appInit.onDeviceReady();},3000) 
}else if( userAgent.match( /Android/i )){
	appInit.initialize(); 
	webSwitch=setTimeout(function(){sessionStorage.APP='OFF';appInit.onDeviceReady();},3000)
}else{
	sessionStorage.APP='OFF';
	appInit.onDeviceReady();
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


